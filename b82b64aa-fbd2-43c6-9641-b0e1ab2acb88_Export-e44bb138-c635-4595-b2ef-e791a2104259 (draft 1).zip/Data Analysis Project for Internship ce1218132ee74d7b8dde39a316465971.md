# Data Analysis Project for Internship

## 1. Project Overview 📝

- **Project Title**: Analyzing Exoplanets using Transit Finder Data
- **Goal of the project**:
    
    Characterize Exoplanets: Determine the size, orbital period, and orbital inclination of the confirmed exoplanets using the transit method.
    
    Catalog Exoplanets: Contribute to the cataloging of exoplanets by documenting the properties of newly discovered exoplanets and comparing them to known ones.
    
    Analyze Data Quality: Evaluate the quality of the data, assess uncertainties, and understand the reliability of the measurements.
    
- **Dataset(s) used**: NASA Exoplanet Archive database (4146 planets; [CSV file](https://astro.swarthmore.edu/transits/transit_targets.csv))
- **Team Members**:

## 2. Data Overview 📁

- **Source(s) of the Data**:
    
    Kepler mission: This NASA mission observed thousands of stars over several years, looking for transits, or tiny dips in a star's brightness that may indicate the presence of a planet.
    TESS (Transiting Exoplanet Survey Satellite): Another NASA mission, TESS is surveying the entire sky to find exoplanets around nearby bright stars.
    UKIRT (United Kingdom Infrared Telescope) Microlensing Survey: This survey looked for exoplanets using the technique of gravitational microlensing, which occurs when the gravitational field of a planet bends the light from a distant star.
    
- **Data Size**: 437 KB
- **Brief Description of the Data**: The NASA Exoplanet Archive database is an impressive collection of data on exoplanets, with over 4,000 planets included. The data comes from a variety of sources, including NASA missions like Kepler and TESS, as well as ground-based surveys like the UKIRT Microlensing Survey. The data includes information on the characteristics of the exoplanets, such as their size, mass, and orbit, as well as information on the stars they orbit.

## 3. Data Cleaning and Preparation 🔧

- **Missing Value Treatment**:
- **Outlier Detection & Treatment**:
- **Feature Engineering**:

## 4. Exploratory Data Analysis 🕵️‍♀️

- **Univariate Analysis**:
- **Bivariate Analysis**:
- **Multivariate Analysis**:

## 5. Visualization 📊

- **Graphs and Plots**:
- **Insights Derived from the Visuals**:

## 6. Hypothesis Testing and Insights 🎯

- **Statistical Tests Used**:
- **Findings and Insights**:

## 7. Final Report and Presentation 📑

- **Key Findings**:
- **Limitations of the Analysis**:
- **Recommendations and Next Steps**:

## 8. References and Data Sources 📚

- **Dataset Links**:
- **Research Papers or Articles Referenced**:

## 9. Project Files 📂

- **EDA Code Files**:
- **Data Files**:
- **Presentations or Reports**: